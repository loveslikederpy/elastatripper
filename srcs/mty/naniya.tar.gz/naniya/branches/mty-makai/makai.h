#ifndef MAKAI_H__
#define MAKAI_H__

#define MAKAI_TRUE  1
#define MAKAI_FALSE 0

#endif /* MAKAI_H__ */
