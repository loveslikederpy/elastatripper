/***********************************************************************
 *
 *	file: cp932.h
 *
 *	�����N���X�\
 *
 */

#ifndef CP932_H__
#define CP932_H__

extern unsigned char cp932[];

#endif /* CP932_H__ */

/*
 *	Local Variables:
 *		tab-width:	4
 *	End:
 *
 * EOF */
