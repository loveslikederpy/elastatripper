#ifndef SPECIAL_H__
#define SPECIAL_H__

void	comment( char *str );
FILE	*checkSpecial( char *trip, unsigned char *kind );
void	initSpecial();
void	dispSpecial();

#endif /* SPECIAL_H__ */
