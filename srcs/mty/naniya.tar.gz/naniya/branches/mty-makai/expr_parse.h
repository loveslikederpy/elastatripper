#ifndef EXPR_PARSE_H__
#define EXPR_PARSE_H__

struct ITREE;

extern struct ITREE *expr_parse(char const *filename);

#endif /* EXPR_PARSE_H__ */

/*
 *	Local Variables:
 *		tab-width:	4
 *	End:
 *
 * EOF */
