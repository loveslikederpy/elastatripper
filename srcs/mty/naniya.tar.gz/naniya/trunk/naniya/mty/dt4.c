#include "dt4.h"
#define NULL 0

struct DT dt[] = {
#if 0
#include "4.inc"
#endif
  {""},
};

int dtcnt = sizeof(dt) / sizeof(dt[0]) - 1;
