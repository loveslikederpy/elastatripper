#ifndef DT4_H__
#define DT4_H__

struct DT
{
  unsigned char c[4];
};

extern int dtcnt;
extern struct DT dt[];

#endif /* DT4_H__ */
